dofile("wifi.lua")
dofile("music.lua")
dofile("servo.lua")
dofile("infrared.lua")
dofile("ultrasonic.lua")
dofile("perfume.lua")
dofile("fuhome.lua")
dofile("fuhomeCallback.lua")

dofile("loop_event.lua")

function init_continue() 

end

function uinit()

end
